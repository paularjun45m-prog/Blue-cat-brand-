'use strict';
document.addEventListener('DOMContentLoaded',()=>{
  if(!window.gsap||!window.ScrollTrigger)return;
  gsap.registerPlugin(ScrollTrigger);
  if(window.Lenis){const lenis=new Lenis({duration:1.15,smoothWheel:true});lenis.on('scroll',ScrollTrigger.update);gsap.ticker.add(t=>lenis.raf(t*1000));gsap.ticker.lagSmoothing(0);}
  const hero=document.querySelector('.hero-image');if(hero)gsap.to(hero,{yPercent:18,scale:1.1,ease:'none',scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:true}});
  document.querySelectorAll('.product-grid').forEach(grid=>{const cards=grid.querySelectorAll('.product-card');if(cards.length)gsap.from(cards,{y:35,opacity:0,duration:.7,stagger:.05,ease:'power2.out',scrollTrigger:{trigger:grid,start:'top 90%',once:true}});});
  const progress=document.querySelector('.scroll-progress');if(progress)gsap.to(progress,{scaleX:1,ease:'none',scrollTrigger:{trigger:document.body,start:'top top',end:'bottom bottom',scrub:.25}});
});
