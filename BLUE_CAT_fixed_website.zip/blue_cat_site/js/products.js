'use strict';
const PRODUCTS = [
{id:1,name:"Nocturne Pima Tee",category:"clothing",sub:"t-shirts",price:12000,image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&h=1000&fit=crop",badge:"Signature",desc:"Featherweight Pima cotton."},
{id:2,name:"Azure Crew Tee",category:"clothing",sub:"t-shirts",price:9500,image:"https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800&h=1000&fit=crop",desc:"Relaxed fit, signature blue."},
{id:3,name:"Meridian Oxford Shirt",category:"clothing",sub:"shirts",price:22000,image:"https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&h=1000&fit=crop",desc:"Italian cotton oxford."},
{id:4,name:"Prowl Cashmere Hoodie",category:"clothing",sub:"hoodies",price:45000,image:"https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=800&h=1000&fit=crop",badge:"Limited",desc:"Brushed cashmere blend."},
{id:5,name:"Signature Tuxedo Blazer",category:"clothing",sub:"blazers",price:145000,image:"https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&h=1000&fit=crop",badge:"Signature",desc:"Satin lapel, sapphire lining."},
{id:6,name:"The Blue Cat Suit",category:"clothing",sub:"suits",price:220000,image:"https://images.unsplash.com/photo-1593030103066-0093718efeb9?w=800&h=1000&fit=crop",badge:"Icon",desc:"The house's defining two-piece."},
{id:7,name:"The Blue Cat Top Handle",category:"bags",sub:"handbags",price:285000,image:"https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&h=1000&fit=crop",badge:"Icon",desc:"Gold cat-eye clasp."},
{id:8,name:"Meridian Shoulder Bag",category:"bags",sub:"shoulder-bags",price:145000,image:"https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&h=1000&fit=crop",desc:"Crescent silhouette."},
{id:9,name:"Prowl Low Sneaker",category:"shoes",sub:"sneakers",price:42000,image:"https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800&h=1000&fit=crop",desc:"Leather upper, sapphire sole."},
{id:10,name:"Blue Cat Pendant Necklace",category:"jewelry",sub:"necklaces",price:88000,image:"https://images.unsplash.com/photo-1599643477877-530eb83abc8e?w=800&h=1000&fit=crop",badge:"Icon",desc:"Sapphire enamel cat charm."},
{id:11,name:"The Blue Cat Automatic",category:"watches",sub:"luxury-watches",price:485000,image:"https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=800&h=1000&fit=crop",badge:"Icon",desc:"40mm sapphire dial."},
{id:12,name:"BLUE CAT Signature",category:"fragrance",sub:"unisex-perfume",price:48000,image:"https://images.unsplash.com/photo-1541643600914-78b084683601?w=800&h=1000&fit=crop",badge:"Signature",desc:"Sea salt, vetiver, white amber."},
{id:13,name:"Prowl Bifold",category:"leather",sub:"wallets",price:28000,image:"https://images.unsplash.com/photo-1627123424574-724758594e93?w=800&h=1000&fit=crop",desc:"Vegetable-tanned leather."},
{id:14,name:"Féline Cat-Eye Sunglasses",category:"accessories",sub:"sunglasses",price:42000,image:"https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&h=1000&fit=crop",badge:"Signature",desc:"Sapphire gradient lens."},
{id:15,name:"Nocturne Candle",category:"home",sub:"candles",price:12000,image:"https://images.unsplash.com/photo-1602874801006-e26b7c9e4a3b?w=800&h=1000&fit=crop",desc:"Cedar, amber, fig."}
];
function formatPrice(n){return "৳"+Number(n).toLocaleString("en-BD");}
function getProduct(id){return PRODUCTS.find(p=>p.id===Number(id));}
function subLabel(slug){return slug.split("-").map(w=>w.charAt(0).toUpperCase()+w.slice(1)).join(" ");}
